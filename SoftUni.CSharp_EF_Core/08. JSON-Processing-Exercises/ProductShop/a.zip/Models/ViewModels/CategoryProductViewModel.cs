﻿namespace ProductShop.Models.ViewModels
{
    public class CategoryProductViewModel : IValidated
    {
        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public int ProductId { get; set; }
        public Product Product { get; set; }
        public bool IsValid { get; set; } = true;
    }
}