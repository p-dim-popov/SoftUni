﻿namespace ProductShop.Models
{
    public interface IValidated
    {
        bool IsValid { get; set; }
    }
}