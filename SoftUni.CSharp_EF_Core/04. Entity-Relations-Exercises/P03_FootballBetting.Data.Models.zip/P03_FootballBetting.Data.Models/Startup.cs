﻿namespace P03_FootballBetting.Data.Models
{
    public static class Startup
    {
        public static void Main()
        {

        }
    }
}
